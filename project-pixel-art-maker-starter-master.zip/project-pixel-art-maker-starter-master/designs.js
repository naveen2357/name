//select color input
var boxColor,table,nHeight,nWidth,tableSize;

 boxcolor = document.getElementById("colorPicker");
 table = document.getElementById("pixelCanvas");
 nHeight = document.getElementById("inputHeight");
 nWidth = document.getElementById("inputWidth");
 tableSize = document.getElementById("sizePicker");

tableSize.addEventListener("submit",(event) => {
    //prevent the event occuring
    event.preventDefault();
    let tableHeight = nHeight.value;
    let tableWidth = nWidth.value;
    table.firstElementChild.remove();
    //calling the grid function
    makeGrid(tableHeight,tableWidth);
});

function makeGrid(tableHeight,tableWidth) {
    for (var i = 0; i < tableHeight; i++ ) {
        //inserting the rows to the table by iterating over height 
        var row = table.insertRow(i);
        //inserting columns to the table by iterating over width 
        for (var j = 0; j < tableWidth; j++ ) {
            var box = row.insertCell(j);

            cell.addEventListener("click",(event) => {
                cell.style.backgroundColor = boxColor.value;

            });
        }
    }
}
makeGrid(nHeight.value, nWidth.value);





